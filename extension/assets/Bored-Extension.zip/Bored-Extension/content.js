
let audio = null;

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {

    if (request.action === "playCustomSound") {

        if (audio && !audio.paused) {
            console.log("Custom sound already playing or recently played.");
            return;
        }

        audio = new Audio(chrome.runtime.getURL('assets/sound/sound.mp3'));
        audio.volume = 0.7; // Set the volume (0.0 to 1.0)
        
        audio.play().catch(e => console.error("Error playing custom sound:", e));

        audio.onended = () => {
            console.log("Custom sound finished playing.");
        };
    }
});
