
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {

    if (changeInfo.audible === true && !tab.mutedInfo?.muted) {
        chrome.tabs.update(tabId, { muted: true }, () => {

            if (chrome.runtime.lastError) {
                console.error("Error muting tab:", chrome.runtime.lastError.message);
                return;
            }
            console.log(`Tab ${tabId} muted.`);

            chrome.scripting.executeScript({
                target: { tabId: tabId },
                files: ['content.js']
            }, () => {
                if (chrome.runtime.lastError) {
                    console.error("Error injecting script:", chrome.runtime.lastError.message);
                    return;
                }
                console.log(`Content script injected into tab ${tabId}.`);

                chrome.tabs.sendMessage(tabId, { action: "playCustomSound" }).catch(e => {
                    console.error("Error sending message to content script:", e);
                });
            });
        });
    }
});
